# FrontEnd MSUPE Video Conferencing

Этот репозиторий создан для команды FrontEnd.

# Состав:
Рита

Настя

Азиз

Лёша
